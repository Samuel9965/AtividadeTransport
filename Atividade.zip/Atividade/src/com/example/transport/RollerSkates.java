package com.example.transport;

public class RollerSkates implements Transport {
    @Override
    public void ride() {
        System.out.println("Você está andando de RollerSkates!");
    }
}

