package com.example.transport;

public class ElectricScooter implements Transport {
    @Override
    public void ride() {
        System.out.println("Você está andando em uma eletricScooter!");
    }
}
