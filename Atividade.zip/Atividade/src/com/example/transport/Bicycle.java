package com.example.transport;

public class Bicycle implements Transport {
    @Override
    public void ride() {
        System.out.println("Você está andando de bicicleta convencional!");
    }
}
